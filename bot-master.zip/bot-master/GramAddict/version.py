# that file is deprecated, current version is now stored in GramAddict/__init__.py
__version__ = "3.2.12"
