import GramAddict

GramAddict.run()
